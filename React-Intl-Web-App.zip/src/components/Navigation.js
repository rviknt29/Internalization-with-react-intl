import React from "react";
import Home from "./Home";
import About from "./About";
import { FormattedMessage } from "react-intl";

const Navigation = (props) => {
  // const intl = useIntl();

  return (
    <div>
      <button style={{marginBottom: "2rem"}} onClick={props.changeLanguage}>
        <FormattedMessage id="buttonText" />
      </button>
      <Home />
      <About />
    </div>
  );
};

export default Navigation;
