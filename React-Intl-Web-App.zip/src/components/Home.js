import React from "react";
import { FormattedMessage, useIntl } from "react-intl";

const Home = () => {
  const intl = useIntl();
  const currLanguage = "German";
  // API response content in English
  const apiResponseContent = {
    greeting: "hello ! Good morning",
    message: "welcome to India",
  };
  const testJsxText = intl.formatMessage(
    { id: "test_jsx_text" },
    { currLanguage }
  );
  return (
    <div style={{ marginBottom: "2rem" }}>
      <FormattedMessage id="Home" />
      <div>
        <FormattedMessage id="language_text" />
      </div>
      <span>
        <p>{testJsxText}</p>
      </span>
      <div style={{marginTop: "2rem"}}>
        <p>
          <FormattedMessage id={apiResponseContent.greeting} />{" "}
          {/* Translated to German */}
        </p>
        <p>
          <FormattedMessage id={apiResponseContent.message} />{" "}
          {/* Translated to German */}
        </p>
      </div>
    </div>
  );
};

export default Home;

// About.js remains the same as Home.js
