import React from "react";
import { FormattedMessage } from "react-intl";

const About = () => {
  return (
    <div>
      <FormattedMessage id="about" />
      <div>
        <FormattedMessage id="language_text" />
      </div>
      <span>
        <FormattedMessage id="test_jsx_text" />
      </span>
    </div>
  );
};

export default About;
