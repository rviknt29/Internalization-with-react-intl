import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import HttpApi from 'i18next-http-backend';

i18n.use(HttpApi).use(initReactI18next).init({
  lng: 'en', // Default language
  fallbackLng: 'en', // Fallback language if the translation for the selected language is missing
  backend: {
    loadPath: './locales/{{lng}}/translation.json', // Adjust the path to match your file structure
  },
});

export default i18n;
