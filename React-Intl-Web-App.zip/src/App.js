import React, { useState } from 'react';
import { IntlProvider, addLocaleData } from 'react-intl';
// import enLocaleData from 'react-intel/locale';
import deLocaleData from 'react-intl/locale-data/de';
import Navigation from './components/Navigation';

import enMessages from './locales/en.json';
import deMessages from './locales/de.json';

const App = () => {
  const [locale, setLocale] = useState('en'); // Default language is English

  const messages = {
    en: enMessages,
    de: deMessages,
  };

  const toggleLanguage = () => {
    setLocale(locale === 'en' ? 'de' : 'en');
  };

  return (
    <IntlProvider locale={locale} messages={messages[locale]}>
      <div>
        {/* <button onClick={toggleLanguage}>Toggle Language</button> */}
        <Navigation changeLanguage={toggleLanguage} />
      </div>
    </IntlProvider>
  );
};

export default App;
